const products = [
    { id: 1, name: "Laptop", category: "electronics", price: 800, rating: 4 ,image:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSMWHwm_l5Bhez4pk3NTl58q2FnmrdGFx8vLA&s"  },
    { id: 2, name: "T-shirt", category: "fashion", price: 25, rating: 5 ,image:"https://static.vecteezy.com/system/resources/thumbnails/023/500/595/small/man-s-black-t-shirt-mockup-front-and-back-view-isolated-on-gray-background-generative-ai-photo.jpg" },
    { id: 3, name: "Microwave", category: "home", price: 150, rating: 3 ,image:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRD-kShlCvmSPiAMA8zwJPf-MO5xk9ITiN1aw&s" },
    { id: 4, name: "Face Cream", category: "beauty", price: 30, rating: 4 ,image:"https://img.pikbest.com/wp/202344/beauty-luxury-cosmetic-luxurious-holiday-backdrop-black-cream-texture-background-for-products-and-makeup-perfect-a-brand_9916612.jpg!w700wp" },
    { id: 5, name: "Basketball", category: "sports", price: 20, rating: 4 ,image:"https://st2.depositphotos.com/3526901/6495/i/450/depositphotos_64959281-stock-photo-the-balls-on-a-wooden.jpg" },
    { id: 6, name: "Football", category: "sports", price: 25, rating: 4 ,image:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ09e5iPAfHqLW2FFb3E95rXmWrlP4np7SJsQ&s" },
    { id: 7, name: "Bat", category: "sports", price: 15, rating: 4 ,image:"https://thumbs.dreamstime.com/b/cricket-bat-dark-dramatically-lit-generic-wooden-isolated-background-d-render-91265850.jpg" },
    { id: 8, name: "Refrigrator", category: "electronics", price: 500, rating: 5 ,image:"https://www.shutterstock.com/image-illustration/black-refrigerator-fridge-freezer-on-260nw-2111303321.jpg" },
    { id: 9, name: "LED", category: "electronics", price: 200, rating: 4 ,image:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRJYnUuBwvthTo3gh7sim7CyfvM1lAu_L7cWQ&s" },
    { id: 10, name: "Mobile", category: "electronics", price: 100, rating: 3 ,image:"https://img.freepik.com/premium-photo/black-phone-with-black-background-with-black-background-with-flowers_662214-79559.jpg" },
    { id: 11, name: "Coat", category: "fashion", price: 50, rating: 5 , image:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ6ws1qfasfK7lay2OSnfzbZxAJoFzZHw0Ik1j2Q1jIbXMfrTIb7oAcS1Ay2v9IxNkIabw&usqp=CAU" },
    { id: 12, name: "Tie", category: "fashion", price: 5, rating: 3 ,image:"https://img.freepik.com/free-photo/silk-necktie-tied-elegant-striped-knot-generated-by-ai_188544-20111.jpg" },
    { id: 13, name: "Belt", category: "fashion", price: 15, rating: 3 ,image:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ3qlJ_y0lCLpUOvAHm6_qaNWPPCaBxbEoY6A&s"},
    { id: 14, name: "Jeans", category: "fashion", price: 35, rating: 4 ,image:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTnjyUiL2XZNkA7zHz6g555EFoeryZeDurPxA&s"},
    { id: 15, name: "Computer", category: "electronics", price: 750, rating: 4 ,image:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQN50SXDUakDe5ja1WpvQ33ubU-sozJJf-KBA&s"},
    { id: 16, name: "Soap", category: "beauty", price: 15, rating: 3 ,image:"https://media.istockphoto.com/id/1224319201/photo/block-of-natural-carbon-charcoal-soap-on-black-stone-background-with-bubbles.jpg?s=612x612&w=0&k=20&c=EgpFxwDvDgJwciEtwHpVdqf-pH_ltFNIHOH0gS1sHfE="},
    { id: 17, name: "Snacks", category: "home", price: 5, rating: 5 ,image:"https://c8.alamy.com/comp/2DE0P45/crunchy-potato-chips-rain-suitable-for-chips-snack-and-fast-food-themes-3d-illustration-with-black-background-2DE0P45.jpg"},
    { id: 18, name: "Air Pods", category: "electronic", price: 150, rating: 5 ,image:"https://wallpapers.com/images/hd/airpods-jet-black-earbuds-zwqe9h9396ey5p6y.jpg"},
    { id: 19, name: "Earphones", category: "electronic", price: 15, rating: 3 ,image:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQMRiXnlg5MsKe55WgJEP04of3AZ-m2TsT0JkNNx7F-5P5lVN891yw_uugQQkmv5ZxVZbQ&usqp=CAU"},
    { id: 20, name: "Cricket Kit", category: "sports", price: 55, rating: 4 ,image:"https://www.shutterstock.com/image-vector/silhouette-cricket-kit-260nw-15083971.jpg"},
];


function displayProducts(productsToDisplay) {
    const productList = document.getElementById('products');
    productList.innerHTML = productsToDisplay.map(product => `
        <div class="product" style="background-image: url('${product.image}'); padding: 20px; background-size: cover; color: white; text-shadow: 2px 2px black;">
            <h3>${product.name}</h3>
            <p>Category: ${product.category}</p>
            <p>Price: $${product.price}</p>
            <p>Rating: ${product.rating} stars</p>
            <button onclick="addToCart(${product.id})">Add to Cart</button>
        </div>
    `).join('');
}


function filterProducts() {
    const category = document.getElementById('category-filter').value;
    const price = Number(document.getElementById('price-filter').value);
    const rating = Number(document.getElementById('rating-filter').value);

    const filteredProducts = products.filter(product =>
        (category === 'all' || product.category === category) &&
        product.price <= price &&
        product.rating >= rating
    );

    displayProducts(filteredProducts);
}  

// Initialize filters and display products
document.getElementById('category-filter').addEventListener('change', filterProducts);
document.getElementById('price-filter').addEventListener('input', filterProducts);
document.getElementById('rating-filter').addEventListener('input', filterProducts);

displayProducts(products);